/**
 * background.js — Service Worker
 *
 * Think of this as the post office.
 * content.js (running on the webpage) sends letters (API call data) here.
 * background.js then forwards those letters to the DevTools panel.
 *
 * Why is this needed?
 * Content scripts and DevTools panels live in separate "worlds" in Chrome.
 * They can't talk directly — background.js acts as the bridge.
 */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // Only relay API_CALL messages — ignore anything else
  if (message.type === "API_CALL") {

    // Attach the tab ID so the panel knows which tab this came from
    if (sender.tab) {
      message.tabId = sender.tab.id;
    }

    // Broadcast to all listeners (the DevTools panel is one of them)
    chrome.runtime.sendMessage(message).catch(() => {
      // Panel may not be open yet — that's fine, just swallow the error
    });
  }

});
