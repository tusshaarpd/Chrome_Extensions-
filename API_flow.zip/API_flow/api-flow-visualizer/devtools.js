// Creates the "API Flow" tab inside Chrome DevTools
chrome.devtools.panels.create(
  "API Flow",   // Tab label
  "",           // Icon (empty = default)
  "panel.html", // The UI shown when you click the tab
  function(panel) {
    // Panel created successfully — nothing extra needed here
  }
);
