/**
 * interceptor.js — runs INSIDE the page's JavaScript world
 *
 * Why a separate file?
 * Chrome content scripts live in an "isolated world" — they share
 * the DOM with the page but NOT the JS engine. So if content.js
 * does window.fetch = something, the PAGE's own code never sees it.
 *
 * The fix: content.js injects THIS file as a real <script> tag,
 * which makes it run in the same JS world as the page.
 * It then shouts results back via window.postMessage, which
 * content.js listens to and forwards to background.js.
 *
 * Flow:
 *   interceptor.js (page world)
 *     → window.postMessage
 *       → content.js (bridge)
 *         → chrome.runtime.sendMessage
 *           → background.js
 *             → panel.js (DevTools)
 */

(function () {

  // Guard: don't double-inject if the script somehow loads twice
  if (window.__apiFlowInjected) return;
  window.__apiFlowInjected = true;

  // ── Helper: post a captured call back to content.js ──────────────
  function report(data) {
    window.postMessage({ source: "api-flow-interceptor", ...data }, "*");
  }

  // ──────────────────────────────────────────────────────────────────
  // 1. Intercept fetch()
  // ──────────────────────────────────────────────────────────────────
  const originalFetch = window.fetch;

  window.fetch = async function (...args) {

    const start = Date.now();

    // Parse URL + method from fetch(url) or fetch(new Request(url))
    let url = "";
    let method = "GET";

    if (typeof args[0] === "string") {
      url = args[0];
    } else if (args[0] instanceof Request) {
      url = args[0].url;
      method = args[0].method || "GET";
    }
    if (args[1] && args[1].method) {
      method = args[1].method.toUpperCase();
    }

    // Skip chrome-extension:// and data: URLs — not API calls
    // Also skip known ad/tracker noise that would pollute the panel
    const SKIP_DOMAINS = ["taboola.com", "doubleclick.net", "googlesyndication.com",
                          "adnxs.com", "moatads.com", "amazon-adsystem.com"];
    if (url.startsWith("chrome-extension://") || url.startsWith("data:") ||
        SKIP_DOMAINS.some(d => url.includes(d))) {
      return originalFetch.apply(this, args);
    }

    let status = null;

    try {
      const response = await originalFetch.apply(this, args);
      status = response.status;

      report({
        type: "API_CALL",
        url,
        method: method.toUpperCase(),
        duration: Date.now() - start,
        status,
        error: null
      });

      return response;

    } catch (err) {
      report({
        type: "API_CALL",
        url,
        method: method.toUpperCase(),
        duration: Date.now() - start,
        status: null,
        error: err.message
      });
      throw err;
    }
  };

  // ──────────────────────────────────────────────────────────────────
  // 2. Intercept XMLHttpRequest (older sites & some libraries)
  // ──────────────────────────────────────────────────────────────────
  const originalOpen = XMLHttpRequest.prototype.open;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {

    this._apiFlowMeta = {
      method: (method || "GET").toUpperCase(),
      url: String(url),
      start: Date.now()
    };

    this.addEventListener("loadend", function () {
      const { method, url, start } = this._apiFlowMeta;
      report({
        type: "API_CALL",
        url,
        method,
        duration: Date.now() - start,
        status: this.status || null,
        error: null
      });
    });

    originalOpen.apply(this, [method, url, ...rest]);
  };

})();
