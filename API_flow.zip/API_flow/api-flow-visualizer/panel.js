/**
 * panel.js — The Display
 *
 * This is what you actually see in the DevTools panel.
 * It listens for API_CALL messages from background.js
 * and turns each one into a readable "card" on screen.
 *
 * Think of it like a flight departures board —
 * each row is one API call, updated in real time.
 */

// ─────────────────────────────────────────────
// State
// ─────────────────────────────────────────────
let allCalls = [];   // Full list of every captured call
let callCount = 0;

const timeline   = document.getElementById("apiTimeline");
const emptyState = document.getElementById("emptyState");
const countBadge = document.getElementById("callCount");
const clearBtn   = document.getElementById("clearBtn");
const searchInput  = document.getElementById("searchInput");
const methodFilter = document.getElementById("methodFilter");
const statusFilter = document.getElementById("statusFilter");


// ─────────────────────────────────────────────
// Listen for messages from background.js
// ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
  if (message.type !== "API_CALL") return;

  callCount++;
  message._id = callCount;
  message._time = new Date().toLocaleTimeString();

  allCalls.unshift(message);   // newest first
  countBadge.textContent = `${callCount} call${callCount !== 1 ? "s" : ""}`;

  renderTimeline();
});


// ─────────────────────────────────────────────
// Clear button
// ─────────────────────────────────────────────
clearBtn.addEventListener("click", () => {
  allCalls = [];
  callCount = 0;
  countBadge.textContent = "0 calls";
  renderTimeline();
});


// ─────────────────────────────────────────────
// Filter controls
// ─────────────────────────────────────────────
searchInput.addEventListener("input", renderTimeline);
methodFilter.addEventListener("change", renderTimeline);
statusFilter.addEventListener("change", renderTimeline);


// ─────────────────────────────────────────────
// Render
// ─────────────────────────────────────────────
function renderTimeline() {
  const search = searchInput.value.toLowerCase();
  const method = methodFilter.value;
  const statusGroup = statusFilter.value;

  const filtered = allCalls.filter(call => {
    // Text search
    if (search && !call.url.toLowerCase().includes(search)) return false;

    // Method filter
    if (method && call.method !== method) return false;

    // Status group filter
    if (statusGroup) {
      const s = call.status;
      if (statusGroup === "ok"       && !(s >= 200 && s < 300)) return false;
      if (statusGroup === "redirect" && !(s >= 300 && s < 400)) return false;
      if (statusGroup === "client"   && !(s >= 400 && s < 500)) return false;
      if (statusGroup === "server"   && !(s >= 500))             return false;
    }

    return true;
  });

  // Show / hide empty state
  emptyState.style.display = filtered.length === 0 ? "block" : "none";

  // Re-render cards
  timeline.innerHTML = "";
  filtered.forEach(call => {
    timeline.appendChild(buildCard(call));
  });
}


// ─────────────────────────────────────────────
// Build a single card for one API call
// ─────────────────────────────────────────────
function buildCard(call) {

  const card = document.createElement("div");
  card.className = "api-card";

  const statusInfo = getStatusInfo(call.status);
  const methodClass = `method-${(call.method || "GET").toLowerCase()}`;
  const latencyClass = getLatencyClass(call.duration);
  const explanation = explainAPI(call.url, call.method, call.status);

  // Try to pull a short readable path from the URL
  let displayUrl = call.url;
  try {
    const u = new URL(call.url);
    displayUrl = u.hostname + u.pathname;
  } catch (e) { /* use raw url */ }

  card.innerHTML = `
    <div class="card-header">
      <span class="method-badge ${methodClass}">${call.method || "?"}</span>
      <span class="endpoint" title="${call.url}">${displayUrl}</span>
      <span class="call-time">${call._time}</span>
    </div>

    <div class="card-meta">
      <span class="status-badge ${statusInfo.cls}">${statusInfo.icon} ${call.status || "—"} ${statusInfo.text}</span>
      <span class="latency ${latencyClass}">⏱ ${
        typeof call.duration === "number"
          ? call.duration + " ms"
          : call.duration
      }</span>
    </div>

    <div class="explanation">
      💬 ${explanation}
    </div>
  `;

  return card;
}


// ─────────────────────────────────────────────
// Plain-English explanation engine
//
// Feynman rule: explain it like someone's mum
// is watching over your shoulder.
// ─────────────────────────────────────────────
function explainAPI(url, method, status) {

  const u = url.toLowerCase();
  const m = (method || "GET").toUpperCase();

  // ── Authentication ──
  if (u.includes("login") || u.includes("signin") || u.includes("sign-in"))
    return m === "POST"
      ? "The app is sending your username and password to the server to check if they match."
      : "The app is loading the login page from the server.";

  if (u.includes("logout") || u.includes("signout"))
    return "The app is telling the server you are done — your session is being closed.";

  if (u.includes("register") || u.includes("signup") || u.includes("sign-up"))
    return "The app is creating a new account by sending your details to the server.";

  if (u.includes("token") || u.includes("refresh") || u.includes("auth"))
    return "The app is renewing or checking your login pass so you stay signed in.";

  if (u.includes("password") && m === "POST")
    return "The app is asking the server to change or reset a password.";

  // ── User / Profile ──
  if (u.includes("profile") || u.includes("/me") || u.includes("/user/"))
    return m === "GET"
      ? "The app is fetching your personal details (name, email, avatar, etc.)."
      : "The app is saving changes to your profile on the server.";

  if (u.includes("avatar") || u.includes("photo") || u.includes("picture"))
    return "The app is uploading or loading a profile picture.";

  if (u.includes("settings") || u.includes("preferences"))
    return m === "GET"
      ? "The app is loading your saved settings and preferences."
      : "The app is saving your updated settings to the server.";

  // ── Search & Discovery ──
  if (u.includes("search") || u.includes("query") || u.includes("find"))
    return "The app is asking the server to search through data and return matching results.";

  if (u.includes("suggest") || u.includes("autocomplete"))
    return "The app is fetching live suggestions as you type in a search box.";

  if (u.includes("filter") || u.includes("sort"))
    return "The app is asking the server to sort or narrow down a list based on your choices.";

  // ── Content / Feed ──
  if (u.includes("feed") || u.includes("timeline") || u.includes("stream"))
    return "The app is loading your personalised content feed from the server.";

  if (u.includes("post") && m === "POST")
    return "The app is publishing new content (a post, comment, or message) to the server.";

  if (u.includes("comment"))
    return m === "POST"
      ? "The app is submitting a new comment to the server."
      : "The app is loading comments from the server.";

  if (u.includes("like") || u.includes("upvote") || u.includes("react"))
    return "The app is recording that you liked or reacted to something.";

  if (u.includes("share") || u.includes("repost"))
    return "The app is sharing or re-posting an item on your behalf.";

  // ── Media ──
  if (u.includes("upload"))
    return "The app is sending a file (image, document, or video) to the server.";

  if (u.includes("download") || u.includes("export"))
    return "The app is downloading a file or report from the server to your browser.";

  if (u.includes("image") || u.includes("img") || u.includes(".jpg") || u.includes(".png"))
    return "The app is fetching an image file from the server.";

  if (u.includes("video") || u.includes("stream") || u.includes("media"))
    return "The app is loading a video or media file for playback.";

  // ── E-commerce ──
  if (u.includes("cart") || u.includes("basket"))
    return m === "POST" || m === "PUT"
      ? "The app is updating the items in your shopping cart."
      : "The app is loading what is currently in your shopping cart.";

  if (u.includes("checkout") || u.includes("order"))
    return m === "POST"
      ? "The app is submitting your order details to the payment or order system."
      : "The app is loading your order details.";

  if (u.includes("payment") || u.includes("charge") || u.includes("billing"))
    return "The app is communicating with the payment system to process or verify a transaction.";

  if (u.includes("product") || u.includes("item") || u.includes("catalog"))
    return m === "GET"
      ? "The app is loading product information to display on screen."
      : "The app is creating or updating a product record.";

  if (u.includes("price") || u.includes("pricing") || u.includes("discount"))
    return "The app is fetching the latest prices or applying a discount.";

  if (u.includes("invoice") || u.includes("receipt"))
    return "The app is loading or creating a payment receipt or invoice.";

  // ── Notifications ──
  if (u.includes("notification") || u.includes("alert") || u.includes("inbox"))
    return m === "GET"
      ? "The app is checking for new notifications or messages."
      : "The app is marking notifications as read or updating them.";

  // ── Analytics & Telemetry ──
  if (u.includes("analytics") || u.includes("telemetry") || u.includes("metrics"))
    return "The app is quietly reporting usage data to its analytics system. This is like a tally counter for the engineers.";

  if (u.includes("event") && (u.includes("track") || u.includes("log")))
    return "The app is logging what you just did (a click, a page view) for analytics purposes.";

  if (u.includes("ping") || u.includes("heartbeat") || u.includes("health"))
    return "The app is doing a quick check to make sure the server is still alive and responding.";

  // ── Config & Feature Flags ──
  if (u.includes("config") || u.includes("feature") || u.includes("flag"))
    return "The app is loading its settings and checking which features are turned on for you.";

  if (u.includes("experiment") || u.includes("ab-test") || u.includes("variant"))
    return "The app is checking which version of a feature you should see — this is A/B testing.";

  // ── Third-party APIs ──
  if (u.includes("maps") || u.includes("geocode") || u.includes("location"))
    return "The app is asking a maps service to look up a location or convert an address to coordinates.";

  if (u.includes("weather") || u.includes("forecast"))
    return "The app is fetching current weather data from a weather API.";

  if (u.includes("translate"))
    return "The app is sending text to a translation service to convert it into another language.";

  if (u.includes("openai") || u.includes("anthropic") || u.includes("gemini") || u.includes("/chat/completions"))
    return "The app is calling an AI language model to generate text or answer a question.";

  if (u.includes("stripe") || u.includes("paypal") || u.includes("braintree"))
    return "The app is talking to a payment processor (Stripe, PayPal, etc.) to handle a transaction.";

  if (u.includes("firebase") || u.includes("supabase") || u.includes("amplify"))
    return "The app is reading from or writing to its cloud database.";

  if (u.includes("twilio") || u.includes("sendgrid") || u.includes("email"))
    return "The app is sending or scheduling an email or SMS notification.";

  // ── Generic fallback by method ──
  if (m === "GET")  return "The app is requesting data from the server to display on this page.";
  if (m === "POST") return "The app is sending new data to the server (creating something).";
  if (m === "PUT" || m === "PATCH")
    return "The app is sending updated data to the server (editing something that already exists).";
  if (m === "DELETE")
    return "The app is asking the server to permanently remove a piece of data.";

  return "The app is communicating with a server. The exact purpose is unclear from the URL alone.";
}


// ─────────────────────────────────────────────
// Status code helpers
// ─────────────────────────────────────────────
function getStatusInfo(status) {
  if (!status) return { icon: "⬜", text: "", cls: "status-unknown" };
  if (status >= 200 && status < 300) return { icon: "✅", text: "OK",     cls: "status-ok" };
  if (status >= 300 && status < 400) return { icon: "↩️", text: "Redirect", cls: "status-redirect" };
  if (status >= 400 && status < 500) return { icon: "⚠️", text: "Client Error", cls: "status-client-error" };
  if (status >= 500)                 return { icon: "🔥", text: "Server Error", cls: "status-server-error" };
  return { icon: "⬜", text: "", cls: "status-unknown" };
}

function getLatencyClass(duration) {
  if (typeof duration !== "number") return "";
  if (duration < 300) return "latency-fast";
  if (duration < 1000) return "latency-medium";
  return "latency-slow";
}
