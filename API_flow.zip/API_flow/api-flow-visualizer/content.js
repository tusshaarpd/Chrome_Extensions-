/**
 * content.js — The Bridge
 *
 * This script runs in Chrome's "isolated world" for every page.
 * It does TWO things:
 *
 * 1. Injects interceptor.js as a real <script> tag so it runs
 *    inside the page's own JavaScript world (where fetch lives).
 *
 * 2. Listens for postMessage events from interceptor.js and
 *    forwards them to background.js via chrome.runtime.sendMessage.
 *
 * Why not just do the interception here?
 * Because content scripts and page scripts are isolated — overriding
 * window.fetch in a content script has NO effect on the page's fetch.
 * Injecting a <script> tag is the standard workaround.
 */

(function () {

  // ── Step 1: Inject interceptor.js into the page ───────────────────
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("interceptor.js");

  // Clean up the tag after it loads — keeps the DOM tidy
  script.onload = function () {
    this.remove();
  };

  // Inject as early as possible — before the page's own scripts run
  (document.head || document.documentElement).appendChild(script);


  // ── Step 2: Listen for results from interceptor.js ────────────────
  window.addEventListener("message", function (event) {

    // Only handle messages from our own interceptor
    if (!event.data || event.data.source !== "api-flow-interceptor") return;
    if (event.data.type !== "API_CALL") return;

    // Forward to background.js (which relays to the DevTools panel)
    try {
      chrome.runtime.sendMessage({
        type:     "API_CALL",
        url:      event.data.url,
        method:   event.data.method,
        duration: event.data.duration,
        status:   event.data.status,
        error:    event.data.error
      });
    } catch (e) {
      // Extension context invalidated on page reload — safe to ignore
    }

  });

})();
